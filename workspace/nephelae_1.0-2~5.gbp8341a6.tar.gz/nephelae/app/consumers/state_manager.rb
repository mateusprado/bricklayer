class StateManager < Consumer
  queue 'StateManager'

  callback do |queue_message|
    vm = VirtualMachine.find(queue_message[:virtual_machine_id])
    
    vm.log_activity(:debug, "#{queue_message[:action]} virtual machine")
    
    case queue_message[:action].to_sym
    when :start then vm.power_on
    when :shutdown then vm.power_off
    when :force_shutdown then vm.force_power_off
    when :restart then vm.reboot
    when :force_restart then vm.force_reboot
    when :uninstall then vm.uninstall
    else
      vm.log_activity(:error, "Unknown action for changing virtual machine state: #{queue_message[:action]}")
      return
    end
      
    vm.log_activity(:info, "#{queue_message[:action]} virtual machine done")
  end
end
