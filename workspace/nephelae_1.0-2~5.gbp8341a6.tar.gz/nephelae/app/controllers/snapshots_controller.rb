class SnapshotsController < ApplicationController
  
  before_filter :find_virtual_machine
  before_filter :find_snapshot, :except => [:index, :new, :create]

  def index
    @snapshots = @machine.snapshots
  end
  
  def new
    @snapshot = Snapshot.new
    
    render :layout => false if request.xhr?
  end
  
  def create
    @snapshot = @machine.snapshots.build(params[:snapshot])
    
    respond_to do |format|
      if @snapshot.save
        format.html do
          flash[:notice] = t("snapshots.creation_scheduled")
          redirect_to(virtual_machine_url(@machine))
        end
        format.xml  { render :xml => @snapshot, :status => :created, :location => [@machine, @snapshot] }
        format.json { render :json => @snapshot, :status => :created, :location => [@machine, @snapshot] }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @snapshot.errors, :status => :unprocessable_entity }
        format.json { render :json => @snapshot, :status => :unprocessable_entity }
      end
    end
  end
  
  def revert
    @snapshot.queue_snapshot_revertion
    
    respond_to do |format|
      format.html do
        flash[:notice] = t("snapshots.revertion_scheduled")
        redirect_to(virtual_machine_url(@machine))
      end
      format.xml  { render :xml => @snapshot, :status => :accepted, :location => [@machine, @snapshot] }
      format.json { render :json => @snapshot, :status => :accepted, :location => [@machine, @snapshot] }
    end
  end
    
  
  def destroy
    @snapshot.queue_snapshot_removal
    respond_to do |format|
      format.html do
        flash[:notice] = t("snapshots.removal_scheduled")
        redirect_to(virtual_machine_url(@machine))
      end
      format.xml { head :accepted }
      format.json { head :accepted }
    end
    
  rescue Exception => e
    logger.error(e.message)
    
    respond_to do |format|
      format.html do
        flash[:error] = t("snapshots.deletion_error")
        redirect_to(virtual_machine_url(@machine))
      end
      format.xml { head :not_found }
      format.json { head :not_found }
    end
    
  end
  
  private
  def find_virtual_machine
    @machine = current_account.virtual_machines.find(params[:virtual_machine_id])
  end
  
  def find_snapshot
    @snapshot = @machine.snapshots.find(params[:id])
  end
end
