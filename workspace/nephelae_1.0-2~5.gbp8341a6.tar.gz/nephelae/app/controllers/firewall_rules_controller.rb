class FirewallRulesController < ApplicationController
  before_filter :find_virtual_machine
  before_filter :find_firewall_rule, :except => [:index, :new, :create]
  
  def index
    @firewall_rules = @machine.filter_rules.all
    respond_to do |format|
      format.xml  { render :xml => @firewall_rules }
      format.json { render :json => @firewall_rules }
    end
  end
  
  def new
    @firewall_rule = FilterFirewallRule.new
    
    render :layout => false if request.xhr?
  end
  
  def create
    @firewall_rule = @machine.filter_rules.build(params[:firewall_rule])
    
    respond_to do |format|
      if @firewall_rule.save
        format.html do
          flash[:notice] = t("firewall_rules.creation_scheduled")
          redirect_to(virtual_machine_url(@machine))
        end
        format.xml  { render :xml => @firewall_rule, :status => :created, :location => [@machine, @firewall_rule] }
        format.json { render :json => @firewall_rule, :status => :created, :location => [@machine, @firewall_rule] }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @firewall_rule.errors, :status => :unprocessable_entity }
        format.json { render :json => @firewall_rule, :status => :unprocessable_entity }
      end
    end
  end
  
  def destroy
    @firewall_rule.queue_removal
    
    respond_to do |format|
      format.html do
        flash[:notice] = t("firewall_rules.removal_scheduled")
        redirect_to(virtual_machine_url(@machine))
      end
      format.xml { head :accepted }
      format.json { head :accepted }
    end
    
  rescue Exception => e
    logger.error(e.message)
    
    respond_to do |format|
      format.html do
        flash[:error] = t("firewall_rules.deletion_error")
        redirect_to(virtual_machine_url(@machine))
      end
      format.xml { head :not_found }
      format.json { head :not_found }
    end
  end
  
  private
  def find_virtual_machine
    @machine = current_account.virtual_machines.find(params[:virtual_machine_id])
  end
  
  def find_firewall_rule
    @firewall_rule = @machine.filter_rules.find(params[:id])
  end
  
end