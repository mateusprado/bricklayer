class FirewallRule < ActiveRecord::Base
  belongs_to :virtual_machine
  
  STATUSES = [:done, :inserting, :removing]

  validates_presence_of :virtual_machine, :description
  
  symbolize :status, :in => STATUSES

  after_create :queue_insertion
  before_destroy :queue_removal
  
  def pending?
    status != :done
  end
  
  def queue_insertion
    update_attribute(:status, :inserting)
    FirewallManager.publish(:firewall_rule_id => id, :action => "insert")
  end
  
  def queue_removal
    update_attribute(:status, :removing)
    FirewallManager.publish(:firewall_rule_id => id, :action => "remove")
  end

  def firewall
    virtual_machine.firewall
  end

  def internal_address
    virtual_machine.private_ip.address
  end
end
