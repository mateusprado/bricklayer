class FilterFirewallRule < FirewallRule
  FILTER_PROTOCOLS = [:tcp, :udp]
  symbolize :filter_protocol, :in => FILTER_PROTOCOLS

  validates_presence_of :filter_address, :filter_port, :filter_protocol
  validates_numericality_of :filter_port, :only_integer => true, :greater_than_or_equal_to => 0, :less_than_or_equal_to => 65000

  def insert
    logger.info "Trying to insert a firewall rule for machine: #{virtual_machine.name}, protocol: #{filter_protocol}, port: #{filter_port}"
    ssh_executor = SSHExecutor.new(self.firewall.ip_address, 'sservice')
    result = ssh_executor.exec(:insert_filter_rules, {:rule => self})
    raise "Could no insert filter firewall rule: #{result[:out]}" unless result[:status] == 0
    logger.info "Inserted firewall rule for machine: #{virtual_machine.name}, protocol: #{filter_protocol}, port: #{filter_port}"
    update_attribute(:status, :done)
    result
  end
  
  def remove
    virtual_machine.log_activity(:debug, "Trying to remove a filter firewall rule, protocol: #{filter_protocol}, port: #{filter_port}")
    ssh_executor = SSHExecutor.new(self.firewall.ip_address, 'sservice')
    result = ssh_executor.exec(:remove_filter_rules, {:rule => self})
    virtual_machine.log_activity do
      raise "Could no remove filter firewall rule: #{result[:out]}" unless result[:status] == 0
    end
  
    virtual_machine.log_activity(:info, "Removed firewall rule, protocol: #{filter_protocol}, port: #{filter_port}")
    update_attribute(:status, :done)
    result
  end

  def after_initialize
    self.filter_address ||= '0.0.0.0/0'
    self.description ||= "Firewall rule source: #{filter_address}, protocol: #{filter_protocol}, port: #{filter_port}"
    self.status ||= :inserting
  end

end
