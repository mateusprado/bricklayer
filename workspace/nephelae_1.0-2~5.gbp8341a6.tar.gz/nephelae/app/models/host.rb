class Host < ActiveRecord::Base
  
  belongs_to :zone
  
  validates_presence_of :ip, :name, :username, :password, :zone
  validates_uniqueness_of :ip

  def insert_ebtables_rule_for(vm)
    ssh_executor = SSHExecutor.new(self.ip, self.username)
    result = ssh_executor.exec(:insert_ebtables_rule, {:vm => vm})

    raise "Error inserting ebtables rule: #{result[:out]}" if result[:status] != 0
  end
  
  def remove_ebtables_rule_for(vm)
    ssh_executor = SSHExecutor.new(self.ip, self.username)
    result = ssh_executor.exec(:remove_ebtables_rule, {:vm => vm})
    
    raise "Error removing ebtables rule: #{result[:out]}" if result[:status] != 0
  end
end
