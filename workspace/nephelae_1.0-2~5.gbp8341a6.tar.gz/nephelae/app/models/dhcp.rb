class DHCP < ActiveRecord::Base
  
  def synchronize(dhcp_config)
    logger.info "Synchronizing DHCP configuration for server: #{self.ip}"
    logger.debug "DHCP configuration file to be written is:\n#{dhcp_config}"
   	@ssh_executor = SSHExecutor.new(self.ip, self.username)
   	@ssh_executor.exec(:synchronize_dhcp, {:dhcp_config => dhcp_config})
  end

end
