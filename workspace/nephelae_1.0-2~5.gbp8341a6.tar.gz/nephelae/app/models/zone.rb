class Zone < ActiveRecord::Base
  MINIMUM = 0
  MAXIMUM = 255
  MAX_VMS_PER_CLIENT = 29

  validates_presence_of :name, :number
  validates_numericality_of :number, :greater_than_or_equal_to => MINIMUM, :less_than_or_equal_to => MAXIMUM
  
  has_many :hosts, :autosave => true, :dependent => :destroy
  has_many :matrix_machines, :dependent => :destroy
  has_many :virtual_machines, :dependent => :nullify
  has_many :vlans, :autosave => true, :dependent => :destroy
  has_one :vnc_proxy, :dependent => :destroy
  has_one :firewall, :dependent => :destroy  
  
  def zone
    self
  end
  
  def master
    @master ||= self.hosts.find_by_master(true)
    @master || Host.new
  end

  def master!
    @master = self.hosts.find_by_master(true)
  end
  
  def master_attributes=(attributes)
    attributes[:master] = true
    @master = self.hosts.build(attributes)    
  end

  def maximum_hosts
    16.0
  end

  def maximum_hosts_in_use
    15.0
  end

  def upgrade_slack
    0.1
  end

  def total_memory
    maximum_hosts * 12 * 4096.0
  end

  def allocable_memory
    total_memory * (maximum_hosts_in_use / maximum_hosts) * (1 - upgrade_slack)
  end

  def used_memory
    # FIXME refactor to list.inject
    memory = 0
    hypervisor_session.VM.get_all_records.each_value do |record|
      memory += record['memory_dynamic_max'].to_i unless record['is_a_template'] || record['is_a_snapshot']
    end
    
    memory/(1024*1024) # i MB
  end

  def available_memory
    allocable_memory - used_memory
  end

  def running_machines_for(account)
    virtual_machines.not_awaiting_validation.count(:conditions => {:account_id => account})
  end

  def can_accomodate_machine?(virtual_machine)
    total_machines = running_machines_for(virtual_machine.account)
    virtual_machine.log_activity(:info, "Total machines available in this zone for account #{virtual_machine.account.login}: #{total_machines}")

    inside_max_quantity = total_machines < MAX_VMS_PER_CLIENT
    has_available_memory = virtual_machine.memory <= available_memory
    virtual_machine.log_activity(:info, "Zone has available memory for this virtual_machine? => #{has_available_memory}")

    inside_max_quantity && has_available_memory
  end

  def define_template_uuid_for(system_image)
    matrix = self.matrix_machines.find_by_system_image_id(system_image.id)
    raise "The zone #{self.name} has no matrix machine for the given system image: #{system_image.code}" if matrix.blank?
    
    return create_template_from(matrix) if matrix.template_uuid.nil?
    return replace_template_from(matrix) if matrix.template_copies >= 20
    matrix.template_uuid
  end
  
  def replace_template_from(matrix)
    delete_template_from(matrix)
    create_template_from(matrix)
  end
  
  def create_template_from(matrix)
    storage = define_storage_to_template_of(matrix)
    new_template_uuid = create_template_on_storage_from(matrix, storage)
    
    new_template_uuid
  end
  
  def storages
    @storages = []
    hypervisor_session.SR.get_all.each do |storage_ref|
      storage = hypervisor_session.SR.get_record(storage_ref)
      @storages << Storage.new(storage["name_label"], storage["uuid"], self) if storage["type"] == "nfs"
    end
    
    @storages
  end
  
  def define_storage_to_data_disk_of(machine)
    storage = define_less_used_storage(machine.hdd)
    raise "There is no storage available on zone #{self.name} to create the machine data disk" unless storage
    storage
  end
  
  def save_and_update_hosts!
    # FIXME: Transformar em callback, before save
    transaction do
    	master = self.master
      raise "Invalid object" unless self.valid?

    	self.hosts.destroy_all
    	host_refs = hypervisor_session.host.get_all
    	host_refs.each do |host_ref|
    		host = hypervisor_session.host.get_record(host_ref)
    		self.hosts << Host.create!(
			    :name => host["name_label"], 
			    :ip => host["address"], 
			    :username => master.username, 
			    :password => master.password, 
			    :zone => self,
			    :master => (host["address"] == master.ip)
		    )
    	end
    	self.save!
    end
  end
  
  def save_and_update_hosts
    begin
      save_and_update_hosts!
      true
    rescue ActiveRecord::RecordInvalid => exception
      exception.record.errors.each do |field, error|
        self.errors.add(:master, "#{field} #{error}")
      end
      false
    rescue => exception
      self.errors.add(:master, "Couldn't update all zone hosts: #{exception}")
      false
    end
  end
  
  def generate_vlans(range = Vlan::MINIMUM..Vlan::MAXIMUM)
    transaction do
      range.each do |vlan_number|
        self.vlans.create!(:number => vlan_number)
      end
    end
  end

  private    
  def create_template_on_storage_from(matrix, on_storage)
    logger.info "Creating template from matrix #{matrix.uuid}"
    storage = hypervisor_session.SR.get_by_uuid(on_storage.uuid)
    vm_matrix = hypervisor_session.VM.get_by_uuid(matrix.uuid)
    logger.info "Copying vm matrix #{matrix.uuid}"
    template = hypervisor_session.VM.copy(vm_matrix, "#{matrix.name}-Template", storage)
    hypervisor_session.VM.set_is_a_template(template, true)
    new_template_uuid = hypervisor_session.VM.get_uuid(template)
  
    matrix.template_uuid = new_template_uuid
    matrix.template_copies = 0
    matrix.save!
    new_template_uuid
  end
  
  def define_storage_to_template_of(matrix)
    vm_matrix = hypervisor_session.VM.get_by_uuid(matrix.uuid)
    vm_matrix_record = hypervisor_session.VM.get_record(vm_matrix)
    matrix_size = vm_matrix_record['physical_size']

    storage = define_less_used_storage(matrix_size)
    raise "There is no storage available on zone #{self.name} to create template" unless storage

    storage
  end

  def define_less_used_storage(size)
    @storages = self.storages
    @storages.each do |storage|
      sr = hypervisor_session.SR.get_by_uuid(storage.uuid)
      record = hypervisor_session.SR.get_record(sr)
      storage.size = record["physical_size"].to_f
      storage.used_ratio = record["virtual_allocation"].to_f / record["physical_size"].to_f
    end
    
    less_used_storage = @storages.min { |a,b| a.used_ratio <=> b.used_ratio }
    
    free_space = (Storage::OVERSELLING * less_used_storage.size) - (less_used_storage.size * less_used_storage.used_ratio)

    less_used_storage unless free_space < size.to_f
  end
  
  def delete_template_from(matrix)
    template = hypervisor_session.VM.get_by_uuid(matrix.template_uuid)
    response = hypervisor_session.VM.destroy(template)
    matrix.template_copies = 0
  end
end
