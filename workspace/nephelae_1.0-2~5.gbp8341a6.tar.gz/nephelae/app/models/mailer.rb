class Mailer < ActionMailer::Base

  def error_email(entity, error)
    recipients   NephelaeConfig[:error_recipients]
    from         "cloud@locaweb.com.br"
    subject      "[Cloud] #{error.class} happened"
    sent_on      Time.now 
    body         :error => error, :entity => entity 
    content_type "text/html" 
  end

end
