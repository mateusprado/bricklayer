class MatrixMachine < ActiveRecord::Base
  belongs_to :zone
  belongs_to :system_image
  
  validates_presence_of :name
  validates_presence_of :uuid
  validates_uniqueness_of :uuid
end
