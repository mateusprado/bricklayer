SimplesIdeias::I18n.export!
Synthesis::AssetPackage.build_all if Rails.env.production?
