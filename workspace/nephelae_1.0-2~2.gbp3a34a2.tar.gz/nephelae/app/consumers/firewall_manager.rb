class FirewallManager < Consumer
  queue 'FirewallManager'

  callback do |queue_message|
    rule = FirewallRule.find(queue_message[:firewall_rule_id])
    
    logger.info("#{queue_message[:action]} rule for #{rule.id}")
    
    case queue_message[:action]
    when "insert" then rule.insert
    when "remove" then rule.remove
    else
      logger.error("Unknown action for firewall rule management: #{queue_message[:action]}")
    end
    
    rule.update_attribute(:status, :done) unless rule.frozen?
      
    logger.info("#{queue_message[:action]} firewall rule done")
  end
end
