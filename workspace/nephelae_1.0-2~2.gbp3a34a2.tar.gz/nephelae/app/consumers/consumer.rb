class Consumer
  
  RETRY_COUNT = 2

  RETRY_COUNT = 2

  class << self
    attr_reader :queue_name, :queued_process, :headers

    def queue(name)
      @queue_name = "/queue/#{name}"
    end

    def exclusive(param)
      @exclusive = param
    end

    def exclusive?
      !!@exclusive
    end

    def callback(&block)
      @queued_process = block
    end

    def headers
      {
        :ack                     => "client",
        :'activemq.prefetchSize' => 1,
        :'activemq.exclusive'    => exclusive?
      }
    end

    def publish(message = {})
      client = Stomp::Client.new(NephelaeConfig[:broker].merge(:max_reconnect_attempts => 1))
      begin
        client.publish(queue_name, message.to_yaml, {:persistent => true, :suppress_content_length => true})
      ensure
        client.close
      end
    end
  end

  def initialize
    if queued_process
      self.class.send(:define_method, :handle, &queued_process)
    end
  end

  def queue_name
    @queue_name ||= self.class.queue_name
  end

  def start
    raise ArgumentError, "No callback supplied" unless respond_to?(:handle)
    broker_client.subscribe(queue_name, self.class.headers) do |message|
      execute_process(message)
    end
  end

  private
    def queued_process
      @queued_process ||= self.class.queued_process
    end

    def broker_client
      @broker_client ||= Stomp::Client.new(NephelaeConfig[:broker])
    end

    def logger
      @logger ||= Logger.new(RAILS_ROOT + '/log/consumers.log', 'weekly')
      @logger.progname = @queue_name
      @logger.formatter = Logger::Formatter.new
      @logger
    end

    def execute_process(raw_queue_message)
      begin
        logger.info("Received #{queue_name} msg: #{raw_queue_message.body}")

        process_message_and_callback raw_queue_message
        broker_client.acknowledge(raw_queue_message)
      rescue Exception => error
        message = "Error processing message for #{queue_name}: #{error.message}"
        message << error.backtrace.join("\n") rescue nil
        logger.error(message)

        begin
          retry_count = (raw_queue_message.headers["retry_count"] || 0).to_i
          ProcessingError.create(:consumer => self.class.to_s,
                                 :error_message => error.message,
                                 :queue_message => raw_queue_message.body) if retry_count > RETRY_COUNT

          broker_client.unreceive(raw_queue_message, :max_redeliveries => RETRY_COUNT)
          logger.info("Message requeued to #{queue_name}")
        rescue Exception => error
          logger.error("Unable to requeue message for #{queue_name}: #{error.message}")
        end
      end
    end

    def process_message_and_callback(raw_queue_message)
      message_details = {:headers => raw_queue_message.headers}.merge(YAML::load(raw_queue_message.body))
      handle(message_details)
    end
end
