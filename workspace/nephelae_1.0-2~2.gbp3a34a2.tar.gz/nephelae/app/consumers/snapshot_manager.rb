class SnapshotManager < Consumer
  queue 'SnapshotManager'

  callback do |queue_message|
    snapshot = Snapshot.find(queue_message[:snapshot_id])
    
    logger.info("#{queue_message[:action]} snapshot for #{snapshot.id}")
    
    case queue_message[:action]
    when "create" then snapshot.create_on_hypervisor
    when "remove" then snapshot.destroy
    when "revert" then snapshot.revert
    else
      logger.error("Unknown action for snapshot management: #{queue_message[:action]}")
    end
    
    snapshot.update_attribute(:status, :done) unless snapshot.frozen?
      
    logger.info("#{queue_message[:action]} snapshot done")
  end
end