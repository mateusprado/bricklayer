class TemplateCloner < Consumer
  queue 'Cloner'
  exclusive true

  callback do |queue_message|
    vm = VirtualMachine.find(queue_message[:virtual_machine_id])
    logger.info "Starting template clone for virtual machine: #{vm.id}"
    vm.clone_from_template
    logger.info "Template clone done. Queueing installation..."
    vm.queue_installation
    logger.info "Installation enqueued."
  end
end
