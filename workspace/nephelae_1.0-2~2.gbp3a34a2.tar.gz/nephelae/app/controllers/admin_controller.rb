class AdminController < ApplicationController
  skip_filter CASClient::Frameworks::Rails::Filter, 
              :check_permissions
  
  before_filter :authenticate_admin
  
  def index
    breadcrumbs.add :admin, admin_path
  end
  
 private
  def authenticate_admin
    authenticate_or_request_with_http_basic do |id, password| 
      login_successful = id == NephelaeConfig[:admin][:user] && password == NephelaeConfig[:admin][:password]
      session[:admin_user] = id if login_successful
      login_successful
    end
  end

end
