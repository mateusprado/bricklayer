class ConsoleController < ApplicationController
  def index
    @vnc_console = VncConsole.find_by_virtual_machine_id(params[:virtual_machine_id])
  end
end
