class ApplicationController < ActionController::Base
  helper :all
  protect_from_forgery

  #before_filter CASClient::Frameworks::Rails::Filter, :unless => :bypass_cas?
  before_filter :bootstrap_breadcrumbs
  around_filter :check_permissions
  after_filter :close_current_hypervisor_session
  filter_parameter_logging :password
  helper_method :current_account

 private
  def current_account
    #raise AuthenticationProblem, "Not authenticated! Please login first." if session[:cas_user].nil?
    #@current_account ||= Account.find_by_login(session[:cas_user])
    @current_account = Account.first
  end
  
  def si_token
    session[:cas_extra_attributes]["sitoken"]
  end
  
  def bypass_cas?
    (not session[:cas_user].nil?) && (not session[:admin_user].nil?)
  end

  def close_current_hypervisor_session
    HypervisorConnection.close_hypervisor_session!
  end

  def bootstrap_breadcrumbs
    breadcrumbs.add :home, root_path
  end
  
  def check_permissions
    if current_account.nil?
      breadcrumbs.add :dashboard
      render 'dashboard/unauthorized'
    else
      yield
    end
  end

end
