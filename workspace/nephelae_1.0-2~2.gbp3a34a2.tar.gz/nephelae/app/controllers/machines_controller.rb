class MachinesController < ApplicationController
  before_filter :find_virtual_machine, :except => [:index, :new, :create]

  def wizard
    @machine = VirtualMachine.new
    @images = SystemImage.all
    render :layout => false
  end

  def new
    @machine = VirtualMachine.new
  end

  def show
    case
      when @machine.nil?
        flash[:notice] = t 'machines.not_found'
        redirect_to root_url
      when (not @machine.installed?) && [nil, "html"].include?(params[:format])
        flash[:notice] = t 'machines.not_installed_yet'
        redirect_to root_url
      else
        respond_to do |format|
          format.html {
            breadcrumbs.add :instances
            breadcrumbs.add @machine.name, virtual_machine_path(@machine)
          }
          format.xml { render :xml => @machine }
          format.json { render :json => @machine }
        end
    end
  end

  def create
    @machine = current_account.virtual_machines.build(params[:virtual_machine])

    respond_to do |format|
      if @machine.save
        format.html do
          flash[:notice] = t "machines.creation_scheduled"
          redirect_to virtual_machines_url
        end
        format.xml  { render :xml => @machine, :status => :created, :location => @machine }
        format.json { render :json => @machine, :status => :created, :location => @machine }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @machine.errors, :status => :unprocessable_entity }
        # TODO: Mostrar erros para o cliente, mas nao qualquer tipo de erro
        format.json { render :json => @machine, :status => :unprocessable_entity }
      end
    end
  end

  def run
    begin
      @machine.queue_state_change(params[:command])

      respond_to do |format|
        format.html do
          flash[:notice] = t "machines.commands.scheduled"
          if params[:command] = "uninstall"
            redirect_to root_url
          else
            redirect_to(virtual_machine_url(@machine))
          end
        end
      end
    rescue Exception => e
      @machine.log_activity(:error, e)

      respond_to do |format|
        format.html do
          flash[:error] = t("machines.commands.error")
          redirect_to(virtual_machine_url(@machine))
        end
        format.xml { head :unprocessable_entity }
        format.json { head :unprocessable_entity }
      end
    end
  end
  
  private
  def find_virtual_machine
    @machine = current_account.virtual_machines.find_by_id(params[:id])
  end
end
