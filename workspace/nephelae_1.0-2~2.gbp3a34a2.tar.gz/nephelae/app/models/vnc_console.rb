class VncConsole < ActiveRecord::Base
  belongs_to :virtual_machine
  belongs_to :vnc_proxy

  validates_presence_of :virtual_machine, :vnc_proxy
  validates_numericality_of :port, :only_integer => true, :greater_than_or_equal_to => 5900, :less_than_or_equal_to => 65535

  def after_initialize
    if self.port.nil?
      self.port = self.vnc_proxy.port + 1
      self.vnc_proxy.port += 1
      self.vnc_proxy.save
    end
    self.password = gen_password
  end

  private

    def gen_password
      Digest::SHA256.hexdigest("vncpasswd_for_#{virtual_machine.to_param}")[0,8]
    end
end
