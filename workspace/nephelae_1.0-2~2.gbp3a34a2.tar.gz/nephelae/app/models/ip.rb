class Ip < ActiveRecord::Base
  include IpMethods
  belongs_to :ip_range
  has_one :virtual_machine, :foreign_key => :private_ip_id
  
  validates_presence_of :address, :ip_range
  validates_format_of :address, :with => IP_PATTERN
  
  accepts_nested_attributes_for :ip_range
  
  def self.find_free_private_ip(vlan)
    vlan.ips.first :joins => "LEFT JOIN virtual_machines on virtual_machines.private_ip_id = ips.id",
                   :conditions => {:virtual_machines => {:private_ip_id => nil}},
                   :order => :id, :readonly => false
  end
  
  def self.find_free_public_ip
    Ip.first :joins => ["LEFT JOIN virtual_machines on virtual_machines.public_ip_id = ips.id",
                        "JOIN ip_ranges on ip_ranges.id = ips.ip_range_id"],
             :conditions => {:virtual_machines => {:public_ip_id => nil}, :ip_ranges => {:vlan_id => nil}},
             :order => :id, :readonly => false
  end
  
  def mask
    ip_range.mask
  end
  
  def to_s
    self.address
  end
end
