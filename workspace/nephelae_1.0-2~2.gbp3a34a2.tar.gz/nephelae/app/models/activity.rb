class Activity < ActiveRecord::Base

  belongs_to :virtual_machine

end
