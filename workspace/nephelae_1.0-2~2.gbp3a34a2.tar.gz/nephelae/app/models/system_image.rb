class SystemImage < ActiveRecord::Base
  CODES = %w(debian centos windows redhat fedora)

  validates_presence_of :code, :name
  validates_numericality_of :minimum_memory, :minimum_hdd, :minimum_cpus, :greater_than => 0
  validates_inclusion_of :code, :in => CODES
  validates_inclusion_of :architecture, :in => [32, 64]

  default_scope :order => "name asc"

  has_many :matrix_machines
  has_many :virtual_machines
end
