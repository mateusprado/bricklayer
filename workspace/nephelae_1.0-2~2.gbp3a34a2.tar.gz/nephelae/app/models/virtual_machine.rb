class VirtualMachine < ActiveRecord::Base
  include ProcessSpecification, CommonHypervisorOperations, StateOperations

  INSTALLATION_SETUP_STATUSES = [:awaiting_validation, :valid_zone, :name_selected, :public_ip_selected, :invalid_setup]
  CLONE_FROM_TEMPLATE_STATUSES = [:not_created, :template_selected]
  UNINSTALL_STATUSES = [:powered_off, :disks_deleted, :machine_deleted, :xvp_data_deleted, :dhcp_data_deleted, :firewall_rules_deleted, 
                        :filter_chain_cleaned, :ips_released, :zone_released, :uninstalled]
  INSTALL_STATUSES = [:machine_created, :with_production_network, :network_rate_limited, :mac_saved, :data_disk_added, :dhcp_configured,
                      :xvp_configured, :console_created, :gateway_configured, :firewall_configured, :vm_started, :vm_booted, :password_changed,
                      :template_files_cleaned, :vm_ready, :installed]

  STATUSES = INSTALLATION_SETUP_STATUSES + CLONE_FROM_TEMPLATE_STATUSES + UNINSTALL_STATUSES + INSTALL_STATUSES + [:uninstalled]

  VALID_UUID = /^[a-f0-9]{40}$/
  
  belongs_to :system_image
  belongs_to :zone
  belongs_to :vlan
  belongs_to :account
  belongs_to :public_ip, :class_name => "Ip"
  belongs_to :private_ip, :class_name => "Ip"
  has_many :firewall_rules, :dependent => :destroy
  has_many :snapshots, :dependent => :destroy
  has_many :filter_rules, :class_name => "FilterFirewallRule"
  has_many :activities
  has_one :console, :class_name => "VncConsole", :dependent => :destroy

  validates_presence_of :system_image, :cpus, :hdd, :memory, :account, :public_uuid
  validates_numericality_of :cpus, :hdd, :memory
  validates_acceptance_of :terms
  validates_confirmation_of :password, :if => :validates_password?
  validates_strength_of :password, :if => :validates_password?

	named_scope :with_assigned_ip, :joins => :public_ip

  accepts_nested_attributes_for :public_ip, :private_ip

  symbolize :status, :in => STATUSES
  symbolize :state

  named_scope :awaiting_validation, :conditions => {:status => :awaiting_validation}
  named_scope :not_awaiting_validation, :conditions => ["status <> ?", :awaiting_validation]
  named_scope :not_uninstalled, :conditions => ["status <> ?", :uninstalled]

  before_create :choose_zone
  after_create :queue_installation_setup, :if => proc {|vm| vm.status == :awaiting_validation}
  before_validation :generate_public_uuid, :if => proc {|vm| vm.public_uuid.blank? }
  before_validation :validate_minimum_configuration, :validate_account_limits, :if => :new_record?

  def after_initialize
    self.status ||= :awaiting_validation
    self.state ||= :ready
    self.memory ||= 0
    self.hdd ||= 0
    self.cpus ||= 0
  end

  process :of => :uninstall do
    must_be :installed

    transition :force_power_off,
      :from => :installed,
      :to => :powered_off

    transition :delete_disks,
      :from => :powered_off,
      :to => :disks_deleted

    transition :delete_machine,
      :from => :disks_deleted,
      :to => :machine_deleted

    transition :queue_dhcp_synchronization,
      :from => :machine_deleted,
      :to => :dhcp_data_deleted

    transition :queue_xvp_synchronization,
      :from => :dhcp_data_deleted,
      :to => :xvp_data_deleted

    transition :delete_firewall_rules,
      :from => :xvp_data_deleted,
      :to => :firewall_rules_deleted
      
    transition :clean_filter_chain,
      :from => :firewall_rules_deleted,
      :to => :filter_chain_cleaned

    transition :release_ips,
      :from => :filter_chain_cleaned,
      :to => :ips_released

    transition :release_zone,
      :from => :ips_released,
      :to => :zone_released

    transition :notify_uninstall,
      :from => :zone_released,
      :to => :uninstalled
  end

  process :of => :setup_installation do
    must_be :awaiting_validation

    transition :validate_zone_availability,
      :from  => :awaiting_validation,
      :to => :valid_zone

    transition :select_name,
      :from => :valid_zone,
      :to => :name_selected

    transition :select_public_ip,
      :from => :name_selected,
      :to => :public_ip_selected

    transition :select_private_ip,
      :from => :public_ip_selected,
      :to => :not_created
  end

  process :of => :clone_from_template do
    must_be :not_created

    transition :select_template,
        :from => :not_created,
        :to => :template_selected

    transition :create_on_hypervisor,
        :from => :template_selected,
        :to => :machine_created
  end

  process :of => :install do
    must_be :machine_created

    transition :set_network_to_production,
      :from => :machine_created,
      :to => :with_production_network

    transition :set_network_rate_limit,
        :from => :with_production_network,
        :to => :network_rate_limited

    transition :add_data_disk,
      :from => :network_rate_limited,
      :to => :data_disk_added

    transition :queue_dhcp_synchronization,
      :from => :data_disk_added,
      :to => :dhcp_configured

    transition :queue_xvp_synchronization,
      :from => :dhcp_configured,
      :to => :xvp_configured

    transition :create_vnc_console,
      :from => :xvp_configured,
      :to => :console_created

    transition :create_nat_rule,
      :from => :console_created,
      :to => :gateway_configured

    transition :create_default_filter_rules,
      :from => :gateway_configured,
      :to => :firewall_configured

    transition :power_on,
      :from => :firewall_configured,
      :to => :vm_started

    transition :wait_ssh_start_up,
      :from => :vm_started,
      :to => :vm_booted

    transition :change_password,
      :from => :vm_booted,
      :to => :password_changed

    transition :clean_template_files,
      :from => :password_changed,
      :to => :template_files_cleaned

    transition :reboot,
      :from => :template_files_cleaned,
      :to => :vm_ready

    transition :notify_install,
      :from => :vm_ready,
      :to => :installed
  end

  def host
    @host ||= begin
      vm_ref = hypervisor_session.VM.get_by_uuid(self.uuid)
      host_ref = hypervisor_session.VM.get_resident_on(vm_ref)
      host_name = hypervisor_session.host.get_name_label(host_ref)

      current_host = Host.find_by_name(host_name)

      current_host
    end
  end

  # Overrides the original +to_json+ method to return some options by default.
  # Also replaces predicated methods by its counter-part without the exclamation mark.
  def to_json(options = {})
    options = {
      :include => :public_ip,
      :methods => %w[ errors installed? installing? configuring? ],
      :except => %w[ password password_confirmation private_ip_id public_ip_id uuid template uuid account_id system_image_id]
    }.merge(options)

    super(options).gsub(/"(installed|installing|configuring)\?"/, '"\\1"')
  end

  def configuring?
    INSTALLATION_SETUP_STATUSES.include?(status)
  end

  def installing?
    (CLONE_FROM_TEMPLATE_STATUSES + INSTALL_STATUSES).include?(status) && !installed?
  end

  def installed?
    status == :installed
  end

  def uninstalling?
    UNINSTALL_STATUSES.include?(status)
  end

  def uninstalled?
    status == :uninstalled
  end
  
  def awaiting_validation?
    self.status == :awaiting_validation
  end

  def priority
    (memory || 0) * (cpus || 0)
  end

  def firewall
    zone.firewall if zone
  end

  def production_network
    "VLAN#{vlan.number}"
  end

  def rate_limit
    '102400'
  end

  def queue_dhcp_synchronization
    log_activity(:debug, "Writing new DHCP configuration")
    DHCPSynchronizer.publish
  end

  def queue_xvp_synchronization
    log_activity(:debug, "Synchronizing XVP config")
    VncProxySynchronizer.publish
  end

  def queue_installation_setup
    InstallationSetup.publish(:virtual_machine_id => self.to_param)
  end

  def queue_template_clone
    TemplateCloner.publish(:virtual_machine_id => self.to_param)
  end

  def queue_installation
    Installer.publish(:virtual_machine_id => self.to_param)
  end

  def cpu_graph_path
    @cpu_graph_path || @cpu_graph_path = begin
      cpu_png_file = File.join(base_image_dir, "cpu.png")

      number_of_cpus = cpus
      generated_rrd_file = rrd_file
      
      return unless generated_rrd_file

      success = RRD.graph cpu_png_file, :title => "CPU",
                              :width => NephelaeConfig[:graph_dimensions][:width],
                              :height => NephelaeConfig[:graph_dimensions][:height] do
        number_of_cpus.times do |cpu|
          line generated_rrd_file, "cpu#{cpu}" => :average, :color => NephelaeConfig[:graph_colors][cpu], :label => "CPU #{cpu}"
        end
      end

      success ? remove_app_path(cpu_png_file) : ''
    end
  end

  def memory_graph_path
    @memory_graph_path || @memory_graph_path = begin
      memory_png_file = File.join(base_image_dir, "memory.png")
      generated_rrd_file = rrd_file

      return unless generated_rrd_file

      success = RRD.graph memory_png_file, :title => "Memória",
                                 :width => NephelaeConfig[:graph_dimensions][:width],
                                 :height => NephelaeConfig[:graph_dimensions][:height] do
        line generated_rrd_file, :memory => :average, :color => NephelaeConfig[:graph_colors][2], :label => "Memória"
      end

      success ? remove_app_path(memory_png_file) : ''
    end
  end

  def io_graph_path
    @io_graph_path || @io_graph_path = begin
      io_png_file = File.join(base_image_dir, "io.png")

      disk_devices = vm_disk_devices
      generated_rrd_file = rrd_file

      return unless generated_rrd_file

      success = RRD.graph io_png_file, :title => "Leitura e Escrita em disco",
                             :width => NephelaeConfig[:graph_dimensions][:width],
                             :height => NephelaeConfig[:graph_dimensions][:height] do
        disk_devices.each_with_index do |disk_device, index|
          line generated_rrd_file, "vbd_#{disk_device}_read" => :average,
                                   :color => NephelaeConfig[:graph_color_pairs][index][0], :label => "Disco #{index} (Leitura)"
          line generated_rrd_file, "vbd_#{disk_device}_write" => :average,
                                   :color => NephelaeConfig[:graph_color_pairs][index][1], :label => "Disco #{index} (Escrita)"
        end
      end

      success ? remove_app_path(io_png_file) : ''
    end
  end

  def username
    "root"
  end

  def log_activity(level = :debug, data = nil, &block)
    # FIXME: find the log level from config environment and log only those    
    if block_given?
      begin
        return yield
      rescue Exception => e
        data = e
        level = :error
      end
    end
    
    options = {:level => level.to_s}
    
    if data.kind_of?(Exception)
      options.merge!(:message => data.message, :backtrace => data.backtrace.try(:join, "\n"))
    else
      options[:message] = data
    end
    
    activity = activities.create(options)
    logger.send(level, "[##{activity.id}][VM #{self.id}] #{options[:message]}")
    
    # If block raised an exception, we need to raise it again after logging it, 
    # because this method rescued the exception before
    raise data if block_given?
  end
  
  def self.vms_not_uninstalling_and_with_assigned_ip
    VirtualMachine.find(:all, 
                        :joins => "INNER JOIN ips ON ips.id=virtual_machines.public_ip_id",
                        :conditions => ["status NOT IN (:uninstall_statuses) AND virtual_machines.public_ip_id IS NOT NULL",
                        {:uninstall_statuses => VirtualMachine::UNINSTALL_STATUSES}])
  end

  private
    def validate_minimum_configuration
      # It's important to keep the single & so it will evaluate all attributes and return all error messages
      evaluate_system_image_config(:cpus) & evaluate_system_image_config(:hdd) & evaluate_system_image_config(:memory)
    end

    def validate_account_limits
      account.within_limits?(self) unless account.nil?
    end

    def evaluate_system_image_config(attribute)
      result = true
      if system_image
        system_image_minimum = system_image.send("minimum_#{attribute}") || 0
        if (self.send(attribute) || 0) < system_image_minimum
          self.errors.add(attribute, :greater_than_or_equal_to, :count => system_image_minimum)
          result = false
        end
      end
      result
    end

    def generate_public_uuid
      begin
        self.public_uuid = Digest::SHA1.hexdigest("#{Time.now}#{rand}")
      end while VirtualMachine.find_by_public_uuid public_uuid
      public_uuid
    end

    def rrd_file
      @rrd_file ||= load_rrd_file
    end

    def load_rrd_file
      begin
        rrd_data_url = "http://#{host.ip}/vm_rrd?start=0&uuid=#{uuid}"
        Timeout::timeout(10, StandardError) do
          rrd_xml = HTTParty.get(rrd_data_url, :basic_auth => {:username => host.username, :password => host.password})

          temp_dir = File.join(Rails.root, 'tmp', 'vm', "#{id}")
          FileUtils.mkdir_p temp_dir unless File.exist?(temp_dir)

          xml_file = File.join(temp_dir, 'graph_rrd.xml')
          File.open(xml_file, 'w') {|f| f.write(rrd_xml) }

          result = File.join(temp_dir, 'graph.rrd')
          RRD::Base.new(result).restore(xml_file, :overwrite => true)

          result
        end
      rescue Exception => e
        log_activity(:error, e)
        Rails.logger.error "Unable to load RRD file accessing #{rrd_data_url}"
        nil
      end
    end

    def remove_app_path(full_path)
      full_path.gsub("#{Rails.public_path}#{File::Separator}images#{File::Separator}", '')
    end

    def vm_disk_devices
      vm_ref = hypervisor_session.VM.get_by_uuid(self.uuid)
      vm_vbds_refs = hypervisor_session.VM.get_record(vm_ref)['VBDs']

      disks = []

      vm_vbds_refs.each do |vm_vbd_ref|
        vm_vbd_record = hypervisor_session.VBD.get_record(vm_vbd_ref)

        if vm_vbd_record['type'] == "Disk"
          disks.push(vm_vbd_record['device'])
        end
      end

      disks
    end

    def use_cloned_disks_from(snapshot)
      snapshot_ref = hypervisor_session.VM.get_by_uuid(snapshot.uuid)
      snapshot_record = hypervisor_session.VM.get_record(snapshot_ref)
      vm_ref = hypervisor_session.VM.get_by_uuid(self.uuid)

      delete_disks

      snapshot_record['VBDs'].each do |vbd_ref|
        vbd_record = hypervisor_session.VBD.get_record(vbd_ref)
        next if vbd_record['type'] != "Disk"

        vdi_ref = vbd_record['VDI']
        new_vdi_ref = hypervisor_session.VDI.clone(vdi_ref)
        vbd_record["VDI"] = new_vdi_ref
        vbd_record["VM"] = vm_ref
        hypervisor_session.VBD.create(vbd_record)
      end
    end

    def base_image_dir
      directory = File.join(Rails.public_path, 'images', 'vm', "#{public_uuid}")
      FileUtils.mkdir_p directory unless File.exist?(directory)
      directory
    end

    def choose_zone
      if zone.nil?
        raise "Undefined Account for Virtual Machine #{self.to_param}" unless account
        self.zone = Zone.first # TODO: We will choose the zone, or it will chosen? => account.choose_zone_for(self)
      end
      self.zone
    end

    def validates_password?
      new_record? || password.present? || password_confirmation.present?
    end
end
