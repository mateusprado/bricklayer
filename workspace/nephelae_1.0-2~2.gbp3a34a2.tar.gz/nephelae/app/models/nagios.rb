require 'soap/wsdlDriver'

class Nagios
  include RailsLogging
  
  STATUS = {:uninstall => 3}
  NAGIOS_WSDL = NephelaeConfig[:nagios_wsdl]
  
  class << self
    def insert(vm)
      return nil if ignore_nagios?
      wsdl = SOAP::WSDLDriverFactory.new(NAGIOS_WSDL)
      proxy = wsdl.create_rpc_driver
      response = proxy.host(vm.name, vm.name, vm.public_ip)
      raise "Wrong Nagios response: #{response}" unless response =~ /Servidor Inserido/
    end

    def remove(vm)
      return nil if ignore_nagios?
      wsdl = SOAP::WSDLDriverFactory.new(NAGIOS_WSDL)
      proxy = wsdl.create_rpc_driver
      response = proxy.monitor(vm.name, STATUS[:uninstall])
      raise "Wrong Nagios response: #{response}" unless response =~ /Servidor Excluido/
    end

   private
    def ignore_nagios?
      ignore = NephelaeConfig[:nagios_wsdl].blank?
      logger.warn "*****PLEASE CHECK***** Nagios config is missing. Ignoring monitoring for now." if ignore
      ignore
    end
  end

end
