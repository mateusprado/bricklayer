class Account < ActiveRecord::Base
  has_many :virtual_machines, :dependent => :destroy

  validates_presence_of :login
  
  def user
    user_index = login.index('/') || -1
    user_index += 1
    login[user_index..-1]
  end

  def after_initialize
    self.maximum_machine_count ||= 1
    self.maximum_memory ||= 4 * 1024
    self.maximum_hdd ||= 80
    self.maximum_cpus ||= 4
  end

  def zones
    Zone.all :joins => :virtual_machines, :conditions => {:virtual_machines => {:account_id => self.to_param}}
  end

  def within_limits?(virtual_machine)
    errors = []
    if (current_machine_count + 1) > maximum_machine_count
      errors += virtual_machine.errors.add(:base, :exceeded_maximum_machines, :count => maximum_machine_count)
    end

    if (current_allocated_memory + virtual_machine.memory.to_i) > maximum_memory
      errors += virtual_machine.errors.add(:memory, :exceeded_maximum_memory, :limit => maximum_memory)
    end

    if (current_allocated_hdd + virtual_machine.hdd.to_i) > maximum_hdd
      errors += virtual_machine.errors.add(:hdd, :exceeded_maximum_hdd, :limit => maximum_hdd)
    end

    if (current_allocated_cpus + virtual_machine.cpus.to_i) > maximum_cpus
      errors += virtual_machine.errors.add(:cpus, :exceeded_maximum_cpus, :limit => maximum_cpus)
    end
    errors.empty?
  end

  def current_machine_count
    virtual_machines.not_uninstalled.count
  end
  def current_allocated_memory
    virtual_machines.not_uninstalled.sum :memory
  end
  def current_allocated_hdd
    virtual_machines.not_uninstalled.sum :hdd
  end
  def current_allocated_cpus
    virtual_machines.not_uninstalled.sum :cpus
  end

  def choose_zone_for(virtual_machine)
    result = zones.find {|zone| zone.can_accomodate_machine?(virtual_machine) }
    result = Zone.all.find {|zone| zone.can_accomodate_machine?(virtual_machine) } unless result
    result
  end
end
