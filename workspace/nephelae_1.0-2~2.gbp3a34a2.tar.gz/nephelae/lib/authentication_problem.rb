class AuthenticationProblem < StandardError; end
