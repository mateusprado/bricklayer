require 'ext/hash'
