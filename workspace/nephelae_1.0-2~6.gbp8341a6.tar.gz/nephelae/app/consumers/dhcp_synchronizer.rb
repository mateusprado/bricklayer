class DHCPSynchronizer < Consumer
  queue 'DHCP'
  exclusive true

  callback do |queue_message|
    logger.info "Writing new DHCP configuration"
		dhcp_config = build_dhcp_configuration
  	sync_successful = false
    output = {}	
  	DHCP.all.each do |dhcp_server|
      begin
    		response = dhcp_server.synchronize(dhcp_config)
    		sync_successful ||= response[:status] == 0
        output[dhcp_server.ip] = response[:out]
      rescue Exception => error
        logger.error "Failed to synchronize with DHCP server #{dhcp_server.ip} with message #{error}"
      end
  	end

    raise "Unable to set the DHCP configuration on any machine: #{output.to_yaml}" unless sync_successful
    logger.info "DHCP configuration successfuly synchronized"
  end

  private
    def build_dhcp_configuration
      vms = VirtualMachine.vms_not_uninstalling_and_with_assigned_ip                    
    	dhcp_config_template = "#{NephelaeConfig[:templates_path]}/dhcp.conf.erb"
    	dhcp_config = ERB.new(File.read(dhcp_config_template))
    	dhcp_config.result(binding)
    end
end
