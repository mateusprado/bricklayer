module Admin
  class ZonesController < AdminController
    
    before_filter :find_zone, :only => [:edit, :show, :update]
    before_filter :add_breadcrumbs
    before_filter :add_zone_breadcrumb, :only => [:edit, :show]
    

    def new
      @zone = Zone.new
    end
  
    def edit

    end
  
    def show

    end
  
    def update
      @zone.update_attributes(params[:zone])
      if (@zone.save_and_update_hosts)
        redirect_to admin_zones_path
      else
        render :action => 'edit'
      end
    end
  
    def create
      @zone = Zone.new(params[:zone])
      if @zone.save_and_update_hosts
        redirect_to admin_zones_path
      else
        render :action => 'new'
      end
    end
        
    def index
      @zones = Zone.all :include => 'hosts'
    end
  
   private
    def find_zone
      @zone = Zone.find(params[:id])
    end
    
    def add_breadcrumbs
      breadcrumbs.add :admin, admin_path
      breadcrumbs.add t('zones.title'), admin_zones_path
    end
    
    def add_zone_breadcrumb
      breadcrumbs.add @zone.name, admin_zone_path(@zone)
    end
  end
end
