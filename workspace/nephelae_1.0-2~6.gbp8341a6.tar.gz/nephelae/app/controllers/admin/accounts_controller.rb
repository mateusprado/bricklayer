module Admin
  class AccountsController < AdminController
    
    before_filter :find_account, :only => [:edit, :show, :update, :access]
    before_filter :add_breadcrumbs
    before_filter :add_account_breadcrumb, :only => [:edit, :show]

    def new
      @account = Account.new
    end
  
    def edit

    end
  
    def show

    end
  
    def update
      @account.update_attributes(params[:account])
      if @account.save
        redirect_to admin_accounts_path
      else
        render :action => 'edit'
      end
    end
  
    def create
      @account = Account.new(params[:account])
      if @account.save
        redirect_to admin_accounts_path
      else
        render :action => 'new'
      end
    end
        
    def index
      @accounts = Account.all
    end
    
    def access
      session[:cas_user] = @account.login
      redirect_to root_path
    end
  
  private
    def find_account
      @account = Account.find(params[:id])
    end
    
    def add_breadcrumbs
      breadcrumbs.add :admin, admin_path
      breadcrumbs.add t('accounts.title'), admin_accounts_path
    end
    
    def add_account_breadcrumb
      breadcrumbs.add @account.login, admin_account_path(@account)
    end
  end
end
