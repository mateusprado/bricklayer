module Admin
  class VirtualMachinesController < AdminController
    
    def index
      breadcrumbs.add :admin, admin_path
      breadcrumbs.add t('machines.title'), admin_virtual_machines_path
      
      @virtual_machines = VirtualMachine.paginate(:page => params[:page]).all
      
    end
    
    def edit
      breadcrumbs.add :admin, admin_path
      breadcrumbs.add t('machines.title'), admin_virtual_machines_path
      breadcrumbs.add t('machines.edit'), edit_admin_virtual_machine_path
      
      @virtual_machine = VirtualMachine.find(params[:id])
    end
    
    def show
      
    end
    
    def create
      
    end
    
    def update
      edit
      if @virtual_machine.update_attributes(params[:virtual_machine])
        flash[:notice] = t('lerolero')
        redirect_to :action => :index
      else
        render :edit
      end
    end
    
  end  
end
