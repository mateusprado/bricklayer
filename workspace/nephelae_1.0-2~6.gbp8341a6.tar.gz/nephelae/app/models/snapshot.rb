class Snapshot < ActiveRecord::Base
  include HypervisorConnection, CommonHypervisorOperations
  
  STATUSES = [:done, :creating, :removing, :reverting]
  
  belongs_to :virtual_machine
  
  validates_presence_of :name, :virtual_machine
  
  after_create :queue_snapshot_creation
  before_destroy :remove_from_hypervisor
  
  symbolize :status, :in => STATUSES
  
  def after_initialize
    self.status ||= :creating
  end
  
  def zone
    virtual_machine.zone
  end
  
  def pending?
    status != :done
  end
  
  def queue_snapshot_creation
    update_attribute(:status, :creating)
    SnapshotManager.publish(:snapshot_id => id, :action => "create")
  end
  
  def queue_snapshot_removal
    update_attribute(:status, :removing)
    SnapshotManager.publish(:snapshot_id => id, :action => "remove")
  end
  
  def queue_snapshot_revertion
    update_attribute(:status, :reverting)
    virtual_machine.update_attribute(:state, :reverting)
    SnapshotManager.publish(:snapshot_id => self.id, :action => "revert")
  end
  
  def create_on_hypervisor
    vm_ref = hypervisor_session.VM.get_by_uuid(virtual_machine.uuid)
    snapshot_ref = hypervisor_session.VM.snapshot(vm_ref, self.name)
    record = hypervisor_session.VM.get_record(snapshot_ref)
    self.uuid = record["uuid"]
    self.taken_at = record["snapshot_time"].to_time
    self.save!
  end
  
  def revert
    virtual_machine.revert_to(self)
  end
  
  def remove_from_hypervisor
    delete_disks
    delete_machine
  end

end