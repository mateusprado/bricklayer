class Storage
  include HypervisorConnection
  
  OVERSELLING = 1.5
  
  attr_accessor :name, :uuid, :zone, :size, :used_ratio
  
  def initialize(name, uuid, zone)
    self.name = name
    self.uuid = uuid
    self.zone = zone
  end
  
  def create_data_disk_for(vm)
    with_vdi_uuid = create_VDI_for(vm)
    create_VBD_for(vm, with_vdi_uuid)
  end
  
  private
  def create_VDI_for(vm)
    name_label = "#{vm.name} DISK"
    name_description = name_label
    virtual_size = vm.hdd.gigabyte.to_s
    type = "system"
    sharable = false
    read_only = false
    other_config = {}
    xenstore_data = {}
    sm_config = {}
    tags = []
    
    storage_ref = hypervisor_session.SR.get_by_uuid(self.uuid)
    
    vdi_ref = hypervisor_session.VDI.create({
                        :name_label => name_label,
                        :name_description => name_description,
                        :SR => storage_ref,
                        :virtual_size => virtual_size,
                        :type => type,
                        :sharable => sharable,
                        :read_only => read_only,
                        :other_config => other_config,
                        :xenstore_data => xenstore_data,
                        :sm_config => sm_config,
                        :tags => tags
                      })
                      
    
    hypervisor_session.VDI.get_record(vdi_ref)["uuid"]
  end
  
  def create_VBD_for(vm, with_vdi_uuid)
  
    vm_ref = hypervisor_session.VM.get_by_uuid(vm.uuid)
    vdi_ref = hypervisor_session.VDI.get_by_uuid(with_vdi_uuid)
    
    userdevice = "1"
    bootable = false
    mode = "RW"
    type = "Disk"
    unpluggable = false
    empty = false
    other_config = {}
    qos_algorithm_type = ""
    qos_algorithm_params = {}
    
    hypervisor_session.VBD.create({
                        :VM => vm_ref,
                        :VDI => vdi_ref,
                        :userdevice => userdevice,
                        :bootable => bootable,
                        :mode => mode,
                        :type => type,
                        :unpluggable => unpluggable,
                        :empty => empty,
                        :other_config => other_config,
                        :qos_algorithm_type => qos_algorithm_type,
                        :qos_algorithm_params => qos_algorithm_params
                      })
  end
end
