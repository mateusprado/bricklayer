class Firewall < ActiveRecord::Base
  validates_presence_of :ip_address, :zone_id
  belongs_to :zone
  has_many :virtual_machines, :through => :zone
end
