class Vlan < ActiveRecord::Base
  include IpMethods
  
  MINIMUM = 1101
  MAXIMUM = 2000

  belongs_to :zone
  has_many :virtual_machines
  has_one :ip_range, :autosave => true, :dependent => :destroy
  after_create :create_range
  has_many :ips, :through => :ip_range

  validates_presence_of :number, :zone
  validates_numericality_of :number, :greater_than_or_equal_to => MINIMUM, :less_than_or_equal_to => MAXIMUM

  def self.find_for(vm)
    find_used_for(vm) || find_new_for(vm)
  end

  def self.find_used_for(vm)
    Vlan.first :joins => :virtual_machines,
               :conditions => {:zone_id => vm.zone, :virtual_machines => {:account_id => vm.account}}
  end

  def self.find_new_for(vm)
    Vlan.first :joins => "LEFT JOIN virtual_machines on virtual_machines.vlan_id = vlans.id",
               :conditions => {:zone_id => vm.zone, :virtual_machines => {:vlan_id => nil}}

  end

  private
    def create_range
      if zone && number
        ip_part3 = (number - 1101) / 8
        ip_part4 = ((number - 1101) % 8) * 32

        network_ip = "10.#{zone.number}.#{ip_part3}.#{ip_part4}"
        IpRange.create!(:address => network_ip, :mask => 27, :vlan => self)
      end
    end

end
