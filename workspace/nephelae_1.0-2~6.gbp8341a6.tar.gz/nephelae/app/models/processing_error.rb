class ProcessingError < ActiveRecord::Base
  
  def retry
    consumer.constantize.publish YAML::load(queue_message)
    destroy
  end
end