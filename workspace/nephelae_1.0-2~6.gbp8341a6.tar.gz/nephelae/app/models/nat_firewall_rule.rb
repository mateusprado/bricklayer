class NatFirewallRule < FirewallRule
  
  def insert
    ssh_executor = SSHExecutor.new(self.firewall.ip_address, 'sservice')
    result = ssh_executor.exec(:insert_nat_rules, {:rule => self})
    raise "Could no insert nat firewall rule: #{result[:out]}" unless result[:status] == 0
    update_attribute(:status, :done)
  end
  
  def remove
    virtual_machine.log_activity(:debug, "Trying to remove a nat firewall rule")
    ssh_executor = SSHExecutor.new(self.firewall.ip_address, 'sservice')
    result = ssh_executor.exec(:remove_nat_rules, {:rule => self})
    
    virtual_machine.log_activity do
      raise "Could no remove nat firewall rule: #{result[:out]}" unless result[:status] == 0
    end
    
    virtual_machine.log_activity(:info, "Removed nat firewall rule")
    update_attribute(:status, :done)
  end

  def external_address
    virtual_machine.public_ip.address
  end

  def external_mask
    virtual_machine.public_ip.ip_range.mask
  end

  def filter_address
    raise "Filter address is not available for #{self.class}"
  end

  def filter_port
    raise "Filter port is not available for #{self.class}"
  end

  def filter_protocol
    raise "Filter protocol is not available for #{self.class}"
  end
  
  def after_initialize
    self.description ||= "Default Nat Rules for machine: #{virtual_machine.try(:uuid)}"
    self.status ||= :inserting
  end

end
