class IpRange < ActiveRecord::Base
  include IpMethods

  MINIMUM_MASK = 8
  MAXIMUM_MASK = 31
  
  has_many :ips, :autosave => true, :dependent => :destroy
  belongs_to :vlan
  
  validates_presence_of :address, :mask
  validates_numericality_of :mask, :greater_than_or_equal_to => MINIMUM_MASK, :less_than_or_equal_to => MAXIMUM_MASK
  validates_format_of :address, :with => IP_PATTERN
  after_create :create_ips
  
  private
    def create_ips
      ips = generate_ips
      ips.delete default_gateway
      transaction do
        ips.each do |ip|
          Ip.create!(:address => ip, :ip_range => self)
        end
      end
    end
  
end
