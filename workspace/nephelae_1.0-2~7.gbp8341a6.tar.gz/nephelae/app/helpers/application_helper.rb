module ApplicationHelper
  def title(text = nil)
    if text
      @_title = text
    end

    [@_title, "Cloud Server"].compact.join(" - ")
  end

  def machine_status(machine)
    return :error if machine.status == :invalid_setup
    return :installing if machine.installing? || machine.configuring?
    return :installed if machine.installed?
    return :uninstalling if machine.uninstalling?
  end

  def flash_messages
    returning "" do |html|
      flash.each do |name, message|
        html << content_tag(:p, message, :class => "message #{name}")
        flash.discard(name)
      end
    end
  end
  
  def graph_tag(path)
    image_tag path.blank? ? "graph_unavailable_#{I18n.locale}.png" : path
  end
end
