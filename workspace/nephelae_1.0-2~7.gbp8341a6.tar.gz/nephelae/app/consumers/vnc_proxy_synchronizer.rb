class VncProxySynchronizer < Consumer
  queue 'VncProxy'
  exclusive true

  callback do |queue_message|
    logger.info "Synchronizing XVP config"
    VncProxy.all.each do |proxy|
      xvp_config = build_xvp_configuration(proxy)
      proxy.synchronize(xvp_config)
    end
    logger.info "Synchronizing XVP config done"
  end

  private
    def build_xvp_configuration(proxy)
      xvp_config = ERB.new(File.read("#{NephelaeConfig[:templates_path]}/xvp.conf.erb"))
      xvp_config.result(binding)
    end
end
