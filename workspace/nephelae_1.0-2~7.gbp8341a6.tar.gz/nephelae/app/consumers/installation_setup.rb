class InstallationSetup < Consumer
  queue 'InstallationSetup'
  exclusive true

  callback do |queue_message|
    vm = VirtualMachine.find(queue_message[:virtual_machine_id])

    # TODO: Try to refactor the status transition to the state machine
    begin
      logger.info("Setup installation for #{vm.id}")
      vm.setup_installation
      logger.info('Setup done, queueing to template cloner...')
      vm.queue_template_clone
      logger.info('Template cloning enqueued, finishing InstallationSetup...')
    rescue Exception => e
      logger.error(e)
      vm.status = :invalid_setup
      vm.save
    end
  end
end
