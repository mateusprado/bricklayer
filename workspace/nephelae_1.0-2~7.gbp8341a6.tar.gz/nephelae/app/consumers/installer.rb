class Installer < Consumer
  queue 'Installer'

  callback do |queue_message|
    vm = VirtualMachine.find(queue_message[:virtual_machine_id])
    raise "Invalid machine id (#{queue_message[:virtual_machine_id]}) sent to install queue" unless vm
    logger.info "Starting installation process for machine: #{vm.id}"
    vm.install 
  end
end
