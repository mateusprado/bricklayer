module Admin
  class ProcessingErrorsController < AdminController
    
    before_filter :find_processing_error, :only => [:retry, :destroy]
    
    def index
      breadcrumbs.add :admin, admin_path
      breadcrumbs.add t('processing_errors.title'), admin_processing_errors_path
      @processing_errors = ProcessingError.all
    end
  
    def retry
      @processing_error.retry
      flash[:notice] = t('processing_errors.retry_succeeded')
    rescue
      flash[:error] = t('processing_errors.retry_error')
    ensure
      redirect_to admin_processing_errors_path
    end
    
    def destroy
      @processing_error.destroy
      
      flash[:notice] = t('processing_errors.delete_succeeded')
      redirect_to admin_processing_errors_path
    end
    
  private
    def find_processing_error
      @processing_error = ProcessingError.find(params[:id])
    end
  end
end
