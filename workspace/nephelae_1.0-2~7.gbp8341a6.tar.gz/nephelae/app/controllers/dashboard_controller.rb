class DashboardController < ApplicationController
  skip_filter CASClient::Frameworks::Rails::Filter, 
              :check_permissions, 
              :only => :logout
  
  def index
    breadcrumbs.add :dashboard
    @machines = current_account.virtual_machines.not_awaiting_validation.not_uninstalled.all(:include => %w[system_image public_ip])
  end
  
  def logout
    CASClient::Frameworks::Rails::Filter.logout(self, root_url)
  end
end
