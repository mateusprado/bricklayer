class VncProxy < ActiveRecord::Base
  belongs_to :zone
  has_many :vnc_consoles
  validates_presence_of :address, :zone
  
  def after_initialize
    self.port = 5900 if self.port.blank?
  end
  
  def synchronize(xvp_config)
    logger.info "Synchronizing VncProxy configuration for server: #{self.address}"
    logger.debug "XVP configuration file to be written is:\n#{xvp_config}"
    ssh = SSHExecutor.new(self.address, 'root')
    result = ssh.exec(:synchronize_xvp, {:xvp_config => xvp_config})
    raise "Could not synchronize xvp: #{result[:out]}" unless result[:status] == 0
  end

  def encrypted_root_password
    zone.hosts.first.password
  end
end
