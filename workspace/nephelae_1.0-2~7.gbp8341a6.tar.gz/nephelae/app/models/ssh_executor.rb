require 'erb'
require 'ostruct'

class SSHExecutor
  def initialize(host, user, password = nil)
    @host = host
    @user = user
    @password = password
  end

  def exec(file_name, params = nil)
    file = "#{SSHExecutor::scripts_folder}/#{file_name.to_s}.sh.erb"
    
    sh_code = SSHExecutor.render_script(file, params)
    exec_in_ssh(sh_code)
  end

  def self.scripts_folder
    @scripts_folder ||= "#{Rails.root}/#{NephelaeConfig[:scripts_path]}"
  end

  def self.render_script(file, params)
    raise "File #{file} doesn't exist" unless File.exist?(file)
    sh_code_template = File.read(file)
    
    binding = OpenStruct.new(params).send(:binding)
    
    ERB.new(sh_code_template).result(binding)
  end
  
  private
    def exec_in_ssh(command)
      ssh_result = {}
      
      options = use_private_key_authentication_if_password_is_empty
      options[:user_known_hosts_file] = known_hosts_file
      
      Net::SSH.start(@host, @user, options) do |ssh|
        ssh_result = ssh.open_channel do |channel|
          channel[:out] = ""
          channel.exec command

          channel.on_data { |ch, data| ch[:out] << data }
          channel.on_extended_data { |ch, type, data| ch[:out] << data }

          channel.on_request("exit-status") do |ch, request|
            status = request.read_long
            channel[:status] = status
          end
        end
        
        ssh.loop
      end
      
      ssh_result
    end
    
    def use_private_key_authentication_if_password_is_empty
      options = { :timeout => 15 }
      if @password.nil?
        { :keys => ["#{RAILS_ROOT}/config/keys/development.key"] }
      else
        { :password => @password }
      end
    end
    
    def known_hosts_file
      ["#{RAILS_ROOT}/config/ssh/known_hosts"]
    end
end

