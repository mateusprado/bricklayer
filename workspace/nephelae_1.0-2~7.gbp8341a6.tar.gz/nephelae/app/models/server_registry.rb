class ServerRegistry

  DEFAULT_HEADERS = {"User-Agent" => "Painel Locaweb", "Content-type" => "application/x-www-form-urlencoded"}
  XML_PARSER = lambda {|*args| self.parse_xml(args[0])}
  SERVER_REGISTRY_URL = NephelaeConfig[:server_registry]

  def self.remove(vm)
    HTTParty.delete("#{SERVER_REGISTRY_URL}/server/#{vm.name}",{:headers => DEFAULT_HEADERS})
  end
  
  def self.insert(vm)
    machine_params = {:serverType => "GridServer", :managementType => "G0", :datacenter => "ITAPAIUNA", 
                      :operatingSystem => vm.system_image.code, :parentServer => "HM852", :serviceType => "gridserver"}
    headers = DEFAULT_HEADERS.merge( {"Accept" => "application/vnd.locaweb.Server-1.0+xml"} )
    HTTParty.post("#{SERVER_REGISTRY_URL}/server", {:headers => headers, :body => machine_params, :format=>:xml, :parser => XML_PARSER})
  end

  def self.set_mac(vm)
    machine_params = {:macAddress => vm.mac}
    HTTParty.put("#{SERVER_REGISTRY_URL}/server/#{vm.name}/eth0", {:headers => DEFAULT_HEADERS, :body => machine_params})
  end

  def self.update_status(vm)
    machine_params = {:status => "IN_PRODUCTION"}
    HTTParty.put("#{SERVER_REGISTRY_URL}/server/#{vm.name}/status", {:headers => DEFAULT_HEADERS, :body => machine_params})
  end

  private
    def self.parse_xml(body)
      begin
        Hash.from_xml(body)
      rescue => error
        "XML parser error: #{error} for xml: #{body}"
      end
    end

end
