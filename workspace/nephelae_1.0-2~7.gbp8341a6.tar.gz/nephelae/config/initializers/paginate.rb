Paginate.settings.merge!({
    :next_label => 'Próxima página',
    :previous_label => 'Página anterior',
    :format => 'Página %d',
    :show_disabled => false
})

